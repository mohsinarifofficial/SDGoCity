import kivy
from kivy.app import App
from kivy.uix.label import Label
from kivy.core.window import Window
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.floatlayout import FloatLayout

import Database

Window.clearcolor=(0.5, 1, 0.3, 1)
 
class data_holder:
    c=""
class Main_1(Screen):
   
    def __init__(self, **kwargs):
        super(Main_1, self).__init__(**kwargs)
        
        
        scrollview = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.add_widget(scrollview)
        scrolllayout = BoxLayout(orientation='vertical', size_hint_y=None,spacing=20)
        scrolllayout.bind(minimum_height=scrolllayout.setter('height'))  # 
        


        title = Label(text="SDGocity.",bold=True,color=(0, 0.5, 0, 1),font_size=100, size_hint=(None, None), size=(200, 150), pos_hint={'center_x': 0.5, 'top': 1})
        scrolllayout.add_widget(title)
        
        b = Button(text='1. No Poverty',on_press=self.Show_SDG_1,font_size=50, size_hint=(None, None), size=(500, 150), pos_hint={'center_x': 0.32, 'center_y': 0.7},color=(1,1,1,1),background_color=(0, 0.5, 0, 1))
        scrolllayout.add_widget(b)

        b = Button(text='2. Zero Hunger',on_press=self.Show_SDG_2,font_size=50, size_hint=(None, None), size=(500, 150), pos_hint={'center_x': 0.32, 'center_y': 0.9},color=(1,1,1,1),background_color=(0, 0.5, 0, 1))
        scrolllayout.add_widget(b)

        b = Button(text='3. Good Health',on_press=self.Show_SDG_3,font_size=50, size_hint=(None, None), size=(500, 150), pos_hint={'center_x': 0.32, 'center_y': 0.7},color=(1,1,1,1),background_color=(0, 0.5, 0, 1))
        scrolllayout.add_widget(b)
        
        b = Button(text='4. Quality Education',on_press=self.Show_SDG_4,font_size=50, size_hint=(None, None), size=(500, 150), pos_hint={'center_x': 0.32, 'center_y': 0.6},color=(1,1,1,1),background_color=(0, 0.5, 0, 1))
        scrolllayout.add_widget(b)

        b = Button(text='5. Gender Equality',on_press=self.Show_SDG_5,font_size=50, size_hint=(None, None), size=(500, 150), pos_hint={'center_x': 0.32, 'center_y': 0.5},color=(1,1,1,1),background_color=(0, 0.5, 0, 1))
        scrolllayout.add_widget(b)
        
        b = Button(text='6. Clean Water',on_press=self.Show_SDG_6,font_size=50, size_hint=(None, None), size=(500, 150), pos_hint={'center_x': 0.32, 'center_y': 0.2},color=(1,1,1,1),background_color=(0, 0.5, 0, 1))
        scrolllayout.add_widget(b)
        
        

        b = Button(text='7. Affordable energy',on_press=self.Show_SDG_7,font_size=50, size_hint=(None, None), size=(500, 150), pos_hint={'center_x': 0.325, 'center_y': 0.7},color=(1,1,1,1),background_color=(0, 0.5, 0, 1))
        scrolllayout.add_widget(b)

        b = Button(text='8. economic Growth',on_press=self.Show_SDG_8,font_size=50, size_hint=(None, None), size=(500, 150), pos_hint={'center_x': 0.32, 'center_y': 0.7},color=(1,1,1,1),background_color=(0, 0.5, 0, 1))
        scrolllayout.add_widget(b)

        b = Button(text='9. Infrastructurs',on_press=self.Show_SDG_9,font_size=50, size_hint=(None, None), size=(500, 150), pos_hint={'center_x': 0.32, 'center_y': 0.5},color=(1,1,1,1),background_color=(0, 0.5, 0, 1))
        scrolllayout.add_widget(b)

        b = Button(text='Next->',on_press=self.Show_Main2,font_size=50, size_hint=(None, None), size=(300, 100), pos_hint={'center_x': 0.5, 'center_y': 0},color=(1,1,1,1),background_color=(0, 0.5, 0, 1))
        scrolllayout.add_widget(b)
        




        scrollview.add_widget(scrolllayout)
    def Show_Main2(self,instance):
        
        self.manager.current = 'main_2'
     
    def Show_SDG_1(self,instance):
        self.manager.current = '1'
    def Show_SDG_2(self,instance):
        self.manager.current = '2'
    def Show_SDG_3(self,instance):
        self.manager.current = '3'
    def Show_SDG_4(self,instance):
        self.manager.current = '4'
    def Show_SDG_5(self,instance):
        self.manager.current = '5'
    def Show_SDG_6(self,instance):
        self.manager.current = '6'
    def Show_SDG_7(self,instance):
        self.manager.current = '7'
    def Show_SDG_8(self,instance):
        self.manager.current = '8'
    def Show_SDG_9(self,instance):
        self.manager.current = '9'    
         
    
            


        
        


class Main_2(Screen):
    def __init__(self, **kwargs):
        super(Main_2, self).__init__(**kwargs)
        
        
        scrollview = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.add_widget(scrollview)
        scrolllayout = BoxLayout(orientation='vertical', size_hint_y=None,spacing=20)
        scrolllayout.bind(minimum_height=scrolllayout.setter('height'))
        


        title = Label(text="SDGocity.",bold=True,color=(0.7,0.7,0.5,1),font_size=100, size_hint=(None, None), size=(200, 150), pos_hint={'center_x': 0.5, 'top': 1})
        scrolllayout.add_widget(title)
        
        
        
        b = Button(text='10. Reduced Inequality',on_press=self.Show_SDG_10,font_size=45, size_hint=(None, None), size=(500, 150), pos_hint={'center_x': 0.32, 'center_y': 0.5},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)

        b = Button(text='11. Sustainable Community',on_press=self.Show_SDG_11,font_size=45, size_hint=(None, None), size=(550, 150), pos_hint={'center_x': 0.38, 'center_y': 0.3},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        
        b = Button(text='12. Reasonable Consuption',on_press=self.Show_SDG_12,font_size=45, size_hint=(None, None), size=(550, 150), pos_hint={'center_x': 0.38, 'center_y': 0.3},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)

        b = Button(text='13. Climate action',on_press=self.Show_SDG_13,font_size=50, size_hint=(None, None), size=(500, 150), pos_hint={'center_x': 0.32, 'center_y': 0.7},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)

        b = Button(text='14. Life Below Water',on_press=self.Show_SDG_14,font_size=50, size_hint=(None, None), size=(500, 150), pos_hint={'center_x': 0.32, 'center_y': 0.7},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)

        b = Button(text='15. Life On Land',on_press=self.Show_SDG_15,font_size=50, size_hint=(None, None), size=(500, 150), pos_hint={'center_x': 0.32, 'center_y': 0.5},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        
        b = Button(text='16. Peace and Justice',on_press=self.Show_SDG_16,font_size=50, size_hint=(None, None), size=(500, 150), pos_hint={'center_x': 0.38, 'center_y': 0.5},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)

        b = Button(text='17. Partnerships for the Goal',on_press=self.Show_SDG_17,font_size=45, size_hint=(None, None), size=(800, 150), pos_hint={'center_x': 0.45, 'center_y': 0.3},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        
        
        b = Button(text='<-Back',on_press=self.Show_Main1,font_size=50, size_hint=(None, None), size=(300, 100), pos_hint={'center_x': 0.5, 'center_y': 0.1},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        
        


        




        scrollview.add_widget(scrolllayout)
    def Show_Main1(self,instance):
        self.manager.current = 'main_1'
        
    
    
    def Show_SDG_10(self,instance):
        self.manager.current = '10'
    def Show_SDG_11(self,instance):
        self.manager.current = '11'
    def Show_SDG_12(self,instance):
        self.manager.current = '12'
    def Show_SDG_13(self,instance):
        self.manager.current = '13'
    def Show_SDG_14(self,instance):
        self.manager.current = '14'
    def Show_SDG_15(self,instance):
        self.manager.current = '15'
    def Show_SDG_16(self,instance):
        self.manager.current = '16'
    def Show_SDG_17(self,instance):
        self.manager.current = '17'
      

    



class Show_SDG_1(Screen):
    
    def __init__(self, **kwargs):
        
        super(Show_SDG_1, self).__init__(**kwargs)
        
         
        
        scrollview = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.add_widget(scrollview)
        scrolllayout = BoxLayout(orientation='vertical', size_hint_y=None,spacing=20)
        scrolllayout.bind(minimum_height=scrolllayout.setter('height'))
        title = Label(text="\n",bold=True,color=(0.7,0.7,0.5,1),font_size=100, size_hint=(None, None), size=(200, 150), pos_hint={'center_x': 0.5, 'top': 1})
        scrolllayout.add_widget(title)
        b = Button(text='<-Back',on_press=self.Show_Main1,font_size=35, size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.15, 'center_y': 0.96},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        

        label = Label(text=str(Database.SDG1),font_size=30, size_hint_y=None, text_size=(Window.width, None))
        label.bind(texture_size=label.setter('size'))
        scrolllayout.add_widget(label)
        
        scrollview.add_widget(scrolllayout)



    


        
    def Show_Main1(self,instance):
        
        self.manager.current = 'main_1'
        
class Show_SDG_2(Screen):
    
    def __init__(self, **kwargs):
        
        super(Show_SDG_2, self).__init__(**kwargs)
        
         
        
        scrollview = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.add_widget(scrollview)
        scrolllayout = BoxLayout(orientation='vertical', size_hint_y=None,spacing=20)
        scrolllayout.bind(minimum_height=scrolllayout.setter('height'))
         
        title = Label(text="\n",bold=True,color=(0.7,0.7,0.5,1),font_size=100, size_hint=(None, None), size=(200, 150), pos_hint={'center_x': 0.5, 'top': 1})
        scrolllayout.add_widget(title)
        
        b = Button(text='<-Back',on_press=self.Show_Main1,font_size=35, size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.15, 'center_y': 0.96},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        
        label = Label(text=str(Database.SDG2),font_size=30, size_hint_y=None, text_size=(Window.width, None))
        label.bind(texture_size=label.setter('size'))
        scrolllayout.add_widget(label)
        
        scrollview.add_widget(scrolllayout)



    


        
    def Show_Main1(self,instance):
        
        self.manager.current = 'main_1'


class Show_SDG_3(Screen):
    
    def __init__(self, **kwargs):
        
        super(Show_SDG_3, self).__init__(**kwargs)
        
         
        
        scrollview = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.add_widget(scrollview)
        scrolllayout = BoxLayout(orientation='vertical', size_hint_y=None,spacing=20)
        scrolllayout.bind(minimum_height=scrolllayout.setter('height'))
        title = Label(text="\n",bold=True,color=(0.7,0.7,0.5,1),font_size=100, size_hint=(None, None), size=(200, 150), pos_hint={'center_x': 0.5, 'top': 1})
        scrolllayout.add_widget(title)
        
        b = Button(text='<-Back',on_press=self.Show_Main1,font_size=35, size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.15, 'center_y': 0.96},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        
        label = Label(text=str(Database.SDG3),font_size=30, size_hint_y=None, text_size=(Window.width, None))
        label.bind(texture_size=label.setter('size'))
        scrolllayout.add_widget(label)
        
        scrollview.add_widget(scrolllayout)
    def Show_Main1(self,instance):
        
        self.manager.current = 'main_1'


class Show_SDG_4(Screen):
    
    def __init__(self, **kwargs):
        
        super(Show_SDG_4, self).__init__(**kwargs)
        
         
        
        scrollview = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.add_widget(scrollview)
        scrolllayout = BoxLayout(orientation='vertical', size_hint_y=None,spacing=20)
        scrolllayout.bind(minimum_height=scrolllayout.setter('height'))
        title = Label(text="\n",bold=True,color=(0.7,0.7,0.5,1),font_size=100, size_hint=(None, None), size=(200, 150), pos_hint={'center_x': 0.5, 'top': 1})
        scrolllayout.add_widget(title)
        
        b = Button(text='<-Back',on_press=self.Show_Main1,font_size=35, size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.15, 'center_y': 0.96},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        
        label = Label(text=str(Database.SDG4),font_size=30, size_hint_y=None, text_size=(Window.width, None))
        label.bind(texture_size=label.setter('size'))
        scrolllayout.add_widget(label)
        scrollview.add_widget(scrolllayout)



    


        
    def Show_Main1(self,instance):
        
        self.manager.current = 'main_1'


class Show_SDG_5(Screen):
    
    def __init__(self, **kwargs):
        
        super(Show_SDG_5, self).__init__(**kwargs)
        
         
        
        scrollview = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.add_widget(scrollview)
        scrolllayout = BoxLayout(orientation='vertical', size_hint_y=None,spacing=20)
        scrolllayout.bind(minimum_height=scrolllayout.setter('height'))
        title = Label(text="\n",bold=True,color=(0.7,0.7,0.5,1),font_size=100, size_hint=(None, None), size=(200, 150), pos_hint={'center_x': 0.5, 'top': 1})
        scrolllayout.add_widget(title)
        
        b = Button(text='<-Back',on_press=self.Show_Main1,font_size=35, size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.15, 'center_y': 0.96},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        
        label = Label(text=str(Database.SDG5),font_size=30, size_hint_y=None, text_size=(Window.width, None))
        label.bind(texture_size=label.setter('size'))
        scrolllayout.add_widget(label)
        
        scrollview.add_widget(scrolllayout)



    


        
    def Show_Main1(self,instance):
        
        self.manager.current = 'main_1'

class Show_SDG_6(Screen):
    
    def __init__(self, **kwargs):
        
        super(Show_SDG_6, self).__init__(**kwargs)
        
         
        
        scrollview = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.add_widget(scrollview)
        scrolllayout = BoxLayout(orientation='vertical', size_hint_y=None,spacing=20)
        scrolllayout.bind(minimum_height=scrolllayout.setter('height'))
        
        title = Label(text="\n",bold=True,color=(0.7,0.7,0.5,1),font_size=100, size_hint=(None, None), size=(200, 150), pos_hint={'center_x': 0.5, 'top': 1})
        
        scrolllayout.add_widget(title)
        
        b = Button(text='<-Back',on_press=self.Show_Main1,font_size=35, size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.15, 'center_y': 0.96},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        
        label = Label(text=str(Database.SDG6),font_size=30, size_hint_y=None, text_size=(Window.width, None))
        label.bind(texture_size=label.setter('size'))
        scrolllayout.add_widget(label)
        
        scrollview.add_widget(scrolllayout)



    


        
    def Show_Main1(self,instance):
        
        self.manager.current = 'main_1'



class Show_SDG_7(Screen):
    
    def __init__(self, **kwargs):
        
        super(Show_SDG_7, self).__init__(**kwargs)
        
         
        
        scrollview = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.add_widget(scrollview)
        scrolllayout = BoxLayout(orientation='vertical', size_hint_y=None,spacing=20)
        scrolllayout.bind(minimum_height=scrolllayout.setter('height'))
        title = Label(text="\n",bold=True,color=(0.7,0.7,0.5,1),font_size=100, size_hint=(None, None), size=(200, 150), pos_hint={'center_x': 0.5, 'top': 1})
        scrolllayout.add_widget(title)
        
       
        b = Button(text='<-Back',on_press=self.Show_Main2,font_size=35, size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.15, 'center_y': 0.96},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        
        label = Label(text=str(Database.SDG7),font_size=30, size_hint_y=None, text_size=(Window.width, None))
        label.bind(texture_size=label.setter('size'))
        scrolllayout.add_widget(label)
        
        scrollview.add_widget(scrolllayout)



    


        
    def Show_Main2(self,instance):
        
        self.manager.current = 'main_1'
        

class Show_SDG_8(Screen):
    
    def __init__(self, **kwargs):
        
        super(Show_SDG_8, self).__init__(**kwargs)
        
         
        
        scrollview = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.add_widget(scrollview)
        scrolllayout = BoxLayout(orientation='vertical', size_hint_y=None,spacing=20)
        scrolllayout.bind(minimum_height=scrolllayout.setter('height'))
        title = Label(text="\n",bold=True,color=(0.7,0.7,0.5,1),font_size=100, size_hint=(None, None), size=(200, 150), pos_hint={'center_x': 0.5, 'top': 1})
        
        scrolllayout.add_widget(title)
        
        b = Button(text='<-Back',on_press=self.Show_Main2,font_size=35, size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.15, 'center_y': 0.96},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        
        label = Label(text=str(Database.SDG8),font_size=30, size_hint_y=None, text_size=(Window.width, None))
        label.bind(texture_size=label.setter('size'))
        scrolllayout.add_widget(label)
        
        scrollview.add_widget(scrolllayout)



    


        
    def Show_Main2(self,instance):
        
        self.manager.current = 'main_1'
        

class Show_SDG_9(Screen):
    
    def __init__(self, **kwargs):
        
        super(Show_SDG_9, self).__init__(**kwargs)
        
         
        
        scrollview = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.add_widget(scrollview)
        scrolllayout = BoxLayout(orientation='vertical', size_hint_y=None,spacing=20)
        scrolllayout.bind(minimum_height=scrolllayout.setter('height'))
        
        title = Label(text="\n",bold=True,color=(0.7,0.7,0.5,1),font_size=100, size_hint=(None, None), size=(200, 150), pos_hint={'center_x': 0.5, 'top': 1})
        scrolllayout.add_widget(title)
         
        b = Button(text='<-Back',on_press=self.Show_Main2,font_size=35, size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.15, 'center_y': 0.96},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        
        label = Label(text=str(Database.SDG9),font_size=30, size_hint_y=None, text_size=(Window.width, None))
        label.bind(texture_size=label.setter('size'))
        scrolllayout.add_widget(label)
        
        scrollview.add_widget(scrolllayout)



    


        
    def Show_Main2(self,instance):
        
        self.manager.current = 'main_1'
        

class Show_SDG_10(Screen):
    
    def __init__(self, **kwargs):
        
        super(Show_SDG_10, self).__init__(**kwargs)
        
         
        
        scrollview = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.add_widget(scrollview)
        scrolllayout = BoxLayout(orientation='vertical', size_hint_y=None,spacing=20)
        scrolllayout.bind(minimum_height=scrolllayout.setter('height'))
        title = Label(text="\n",bold=True,color=(0.7,0.7,0.5,1),font_size=100, size_hint=(None, None), size=(200, 150), pos_hint={'center_x': 0.5, 'top': 1})
        scrolllayout.add_widget(title)
        
       
        b = Button(text='<-Back',on_press=self.Show_Main2,font_size=35, size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.15, 'center_y': 0.96},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        
        label = Label(text=str(Database.SDG10),font_size=30, size_hint_y=None, text_size=(Window.width, None))
        label.bind(texture_size=label.setter('size'))
        scrolllayout.add_widget(label)
        
        scrollview.add_widget(scrolllayout)



    


        
    def Show_Main2(self,instance):
        
        self.manager.current = 'main_2'
        

class Show_SDG_11(Screen):
    
    def __init__(self, **kwargs):
        
        super(Show_SDG_11, self).__init__(**kwargs)
        
         
        
        scrollview = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.add_widget(scrollview)
        scrolllayout = BoxLayout(orientation='vertical', size_hint_y=None,spacing=20)
        scrolllayout.bind(minimum_height=scrolllayout.setter('height'))
        
        title = Label(text="\n",bold=True,color=(0.7,0.7,0.5,1),font_size=100, size_hint=(None, None), size=(200, 150), pos_hint={'center_x': 0.5, 'top': 1})
        scrolllayout.add_widget(title)
        
        b = Button(text='<-Back',on_press=self.Show_Main2,font_size=35, size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.15, 'center_y': 0.96},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        
        label = Label(text=str(Database.SDG11),font_size=30, size_hint_y=None, text_size=(Window.width, None))
        label.bind(texture_size=label.setter('size'))
        scrolllayout.add_widget(label)
        
        scrollview.add_widget(scrolllayout)



    


        
    def Show_Main2(self,instance):
        
        self.manager.current = 'main_2'
        


class Show_SDG_12(Screen):
    
    def __init__(self, **kwargs):
        
        super(Show_SDG_12, self).__init__(**kwargs)
        
         
        
        scrollview = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.add_widget(scrollview)
        scrolllayout = BoxLayout(orientation='vertical', size_hint_y=None,spacing=20)
        scrolllayout.bind(minimum_height=scrolllayout.setter('height'))
        title = Label(text="\n",bold=True,color=(0.7,0.7,0.5,1),font_size=100, size_hint=(None, None), size=(200, 150), pos_hint={'center_x': 0.5, 'top': 1})
        
        scrolllayout.add_widget(title)
        
        b = Button(text='<-Back',on_press=self.Show_Main2,font_size=35, size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.15, 'center_y': 0.96},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        
        label = Label(text=str(Database.SDG12),font_size=30, size_hint_y=None, text_size=(Window.width, None))
        label.bind(texture_size=label.setter('size'))
        scrolllayout.add_widget(label)
        
        scrollview.add_widget(scrolllayout)



    


        
    def Show_Main2(self,instance):
        
        self.manager.current = 'main_2'
        

class Show_SDG_13(Screen):
    
    def __init__(self, **kwargs):
        
        super(Show_SDG_13, self).__init__(**kwargs)
        
         
        
        scrollview = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.add_widget(scrollview)
        scrolllayout = BoxLayout(orientation='vertical', size_hint_y=None,spacing=20)
        scrolllayout.bind(minimum_height=scrolllayout.setter('height'))
        title = Label(text="\n",bold=True,color=(0.7,0.7,0.5,1),font_size=100, size_hint=(None, None), size=(200, 150), pos_hint={'center_x': 0.5, 'top': 1})
        
        scrolllayout.add_widget(title)
        
        b = Button(text='<-Back',on_press=self.Show_Main3,font_size=35, size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.15, 'center_y': 0.96},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        
        label = Label(text=str(Database.SDG13),font_size=30, size_hint_y=None, text_size=(Window.width, None))
        label.bind(texture_size=label.setter('size'))
        scrolllayout.add_widget(label)
        
        scrollview.add_widget(scrolllayout)



    


        
    def Show_Main3(self,instance):
        
        self.manager.current = 'main_2'
        


class Show_SDG_14(Screen):
    
    def __init__(self, **kwargs):
        
        super(Show_SDG_14, self).__init__(**kwargs)
        
         
        
        scrollview = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.add_widget(scrollview)
        scrolllayout = BoxLayout(orientation='vertical', size_hint_y=None,spacing=20)
        scrolllayout.bind(minimum_height=scrolllayout.setter('height'))
        title = Label(text="\n",bold=True,color=(0.7,0.7,0.5,1),font_size=100, size_hint=(None, None), size=(200, 150), pos_hint={'center_x': 0.5, 'top': 1})
        scrolllayout.add_widget(title)
        
       
        b = Button(text='<-Back',on_press=self.Show_Main3,font_size=35, size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.15, 'center_y': 0.96},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        
        label = Label(text=str(Database.SDG14),font_size=30, size_hint_y=None, text_size=(Window.width, None))
        label.bind(texture_size=label.setter('size'))
        scrolllayout.add_widget(label)
        
        scrollview.add_widget(scrolllayout)



    


        
    def Show_Main3(self,instance):
        
        self.manager.current = 'main_2'
        

class Show_SDG_15(Screen):
    
    def __init__(self, **kwargs):
        
        super(Show_SDG_15, self).__init__(**kwargs)
        
        
        
        scrollview = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.add_widget(scrollview)
        scrolllayout = BoxLayout(orientation='vertical', size_hint_y=None,spacing=20)
        scrolllayout.bind(minimum_height=scrolllayout.setter('height'))
        title = Label(text="\n",bold=True,color=(0.7,0.7,0.5,1),font_size=100, size_hint=(None, None), size=(200, 150), pos_hint={'center_x': 0.5, 'top': 1})
        
        scrolllayout.add_widget(title)
        
       
        b = Button(text='<-Back',on_press=self.Show_Main3,font_size=35, size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.15, 'center_y': 0.96},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        
        label = Label(text=str(Database.SDG15),font_size=30, size_hint_y=None, text_size=(Window.width, None))
        label.bind(texture_size=label.setter('size'))
        scrolllayout.add_widget(label)
        
        scrollview.add_widget(scrolllayout)



    


        
    def Show_Main3(self,instance):
        
        self.manager.current = 'main_2'
        

class Show_SDG_16(Screen):
    
    def __init__(self, **kwargs):
        
        super(Show_SDG_16, self).__init__(**kwargs)
        
        
        
        scrollview = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.add_widget(scrollview)
        scrolllayout = BoxLayout(orientation='vertical', size_hint_y=None,spacing=20)
        scrolllayout.bind(minimum_height=scrolllayout.setter('height'))
        title = Label(text="\n",bold=True,color=(0.7,0.7,0.5,1),font_size=100, size_hint=(None, None), size=(200, 150), pos_hint={'center_x': 0.5, 'top': 1})
        
        scrolllayout.add_widget(title)
        
        b = Button(text='<-Back',on_press=self.Show_Main3,font_size=35, size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.15, 'center_y': 0.96},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        
        label = Label(text=str(Database.SDG16),font_size=30, size_hint_y=None, text_size=(Window.width, None))
        label.bind(texture_size=label.setter('size'))
        scrolllayout.add_widget(label)
        
        scrollview.add_widget(scrolllayout)



    


        
    def Show_Main3(self,instance):
        
        self.manager.current = 'main_2'
        

class Show_SDG_17(Screen):
    
    def __init__(self, **kwargs):
        
        super(Show_SDG_17, self).__init__(**kwargs)
        
        
        
        scrollview = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.add_widget(scrollview)
        scrolllayout = BoxLayout(orientation='vertical', size_hint_y=None,spacing=20)
        scrolllayout.bind(minimum_height=scrolllayout.setter('height'))
        title = Label(text="\n",bold=True,color=(0.7,0.7,0.5,1),font_size=100, size_hint=(None, None), size=(200, 150), pos_hint={'center_x': 0.5, 'top': 1})
        
        scrolllayout.add_widget(title)
        
       
        b = Button(text='<-Back',on_press=self.Show_Main3,font_size=35, size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.15, 'center_y': 0.96},color=(0,0,0.4,1),background_color=(0.7,0.7,0.5,1))
        scrolllayout.add_widget(b)
        
        label = Label(text=str(Database.SDG17),font_size=30, size_hint_y=None, text_size=(Window.width, None))
        label.bind(texture_size=label.setter('size'))
        scrolllayout.add_widget(label)
        
        scrollview.add_widget(scrolllayout)



    


        
    def Show_Main3(self,instance):
        
        self.manager.current = 'main_2'
        


class MyApp(App):
    def build(self):

        screen_manager = ScreenManager()

        main_screen = Main_1(name='main_1')
        screen_manager.add_widget(main_screen)

        main_screen2 = Main_2(name='main_2')
        screen_manager.add_widget(main_screen2)
        
        

        Showing_SDG = Show_SDG_1(name='1')
        screen_manager.add_widget(Showing_SDG)

        Showing_SDG = Show_SDG_2(name='2')
        screen_manager.add_widget(Showing_SDG)

        Showing_SDG = Show_SDG_3(name='3')
        screen_manager.add_widget(Showing_SDG)

        Showing_SDG = Show_SDG_4(name='4')
        screen_manager.add_widget(Showing_SDG)

        Showing_SDG = Show_SDG_5(name='5')
        screen_manager.add_widget(Showing_SDG)

        Showing_SDG = Show_SDG_6(name='6')
        screen_manager.add_widget(Showing_SDG)

        Showing_SDG = Show_SDG_7(name='7')
        screen_manager.add_widget(Showing_SDG)

        Showing_SDG = Show_SDG_8(name='8')
        screen_manager.add_widget(Showing_SDG)
        
        Showing_SDG = Show_SDG_9(name='9')
        screen_manager.add_widget(Showing_SDG)
        
        Showing_SDG = Show_SDG_10(name='10')
        screen_manager.add_widget(Showing_SDG)
        
        Showing_SDG = Show_SDG_11(name='11')
        screen_manager.add_widget(Showing_SDG)
        
        Showing_SDG = Show_SDG_12(name='12')
        screen_manager.add_widget(Showing_SDG)
        
        Showing_SDG = Show_SDG_13(name='13')
        screen_manager.add_widget(Showing_SDG)
        
        Showing_SDG = Show_SDG_14(name='14')
        screen_manager.add_widget(Showing_SDG)
        
        Showing_SDG = Show_SDG_15(name='15')
        screen_manager.add_widget(Showing_SDG)
        
        Showing_SDG = Show_SDG_16(name='16')
        screen_manager.add_widget(Showing_SDG)
        
        Showing_SDG = Show_SDG_17(name='17')
        screen_manager.add_widget(Showing_SDG)
        
       
        


        return screen_manager
    

if __name__ == '__main__':
    MyApp().run()
