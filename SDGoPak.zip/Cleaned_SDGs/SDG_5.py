import requests
from bs4 import BeautifulSoup

def Get_Cleaned_String(raw_text):
    data=""
    for i in raw_text:
        data+=i.text
    return data

html=requests.get("https://www.linkedin.com/pulse/issues-gender-equality-pakistan-sdg-5-professor-dr-qais-aslam",allow_redirects=True)
raw_data=BeautifulSoup(html.content,"html.parser")
raw_data=raw_data.find("div",class_="article-main__content")
#print(raw_data)
SDG5=Get_Cleaned_String(raw_data)
print(SDG5)
