import requests
from bs4 import BeautifulSoup

def Get_Cleaned_String(raw_text):
    data=""
    for i in raw_text:
        data+=i.text
    return data

html=requests.get("https://iips.com.pk/pakistans-progress-on-sdg-12-responsible-consumption-and-production/",allow_redirects=True)
raw_data=BeautifulSoup(html.content,"html.parser")
raw_data=raw_data.find("div",class_="wpb_wrapper")
#print(raw_data)
SDG12=Get_Cleaned_String(raw_data)

not_required="Conclusion"
SDG12=SDG12.replace(not_required,"")

not_required="Not only does wasteful consumption harm the environment, but it is also unsustainable for upcoming generations of human societies. Extraction of resources beyond their demand can lead to unforeseen consequences as regeneration of natural reserves takes time. Pakistan is a country rich in natural reserves. With a growing middle class, the demand for consumables will also increase. In order to protect its environment and natural reserves, Pakistan has taken multiple steps that ensure the achievement of SDG goal 12. The country has seen positive results of its policies in many areas, while challenges remain in many others."
SDG12=SDG12.replace(not_required,"")

not_required="Bibliography"
SDG12=SDG12.replace(not_required,"")
not_required="Ministry of Climate Change. (n.d.). Pakistan National Action Plan on SDG 12 .\nSDG Compass. (2021). SDG 12: Ensure sustainable consumption and production patterns. Retrieved from https://sdgcompass.org/sdgs/sdg-12/\nSDGPakistan. (2021). National Initiative for Sustainable Development Goals. Retrieved from https://www.sdgpakistan.pk/web/goals/goal12\nUN Stats. (2021). Ensure sustainable consumption and production patterns. Retrieved from https://unstats.un.org/sdgs/report/2020/goal-12/\nUN Stats Hub. (2021). SDG Country Profile Pakistan . Retrieved from https://country-profiles.unstatshub.org/pak#goal-12"
SDG12=SDG12.replace(not_required,"")
#print(SDG12)

