import requests
from bs4 import BeautifulSoup

def Get_Cleaned_String(raw_text):
    data=""
    for i in raw_text:
        data+=i.text
    return data

html=requests.get("https://www.telegraphnepal.com/sustainable-development-goal-6-clean-water-and-sanitation-in-pakistan/",allow_redirects=True)
raw_data=BeautifulSoup(html.content,"html.parser")
raw_data=raw_data.find("div",class_="entry-content")
#print(raw_data)
SDG6=Get_Cleaned_String(raw_data)
not_required="WHERE DOES PAKISTAN STAND?\nBy NAUSHEEN SARWAR\nA civil servant of Pakistan"
SDG6=SDG6.replace(not_required,"")

not_required="(adsbygoogle = window.adsbygoogle || []).push({});"
SDG6=SDG6.replace(not_required,"")

#print(SDG6)
