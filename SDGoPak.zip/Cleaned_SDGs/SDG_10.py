import requests
from bs4 import BeautifulSoup

def Get_Cleaned_String(raw_text):
    data=""
    for i in raw_text:
        data+=i.text
    return data

html=requests.get("https://iips.com.pk/pakistans-progress-on-sdg-goal-10-reducing-inequality/",allow_redirects=True)
raw_data=BeautifulSoup(html.content,"html.parser")
raw_data=raw_data.find("div",class_="vc_row wpb_row row top-row text-left")
#print(raw_data)
SDG10=Get_Cleaned_String(raw_data)

not_required="Research Questions\n\nWhat is the significance of SDG Goal 10?\nWhat is the current situation of Pakistan with regards to SDG goal 10?\nWhat can Pakistan do to implement SDG goal 10 properly?"
SDG10=SDG10.replace(not_required,"")
not_required="Bibliography\nGovernment of Pakistan . (2019). Voluntary National Review.\nPlanning Commission. (2018). Summary for the NEC Council: SDGs National Framework.\nQadir, A. (2018). Growth and inequality in Pakistan. Retrieved from https://www.fes-connect.org/people/growth-and-inequality-in-pakistan/#:~:text=The%20most%20prominent%20manifestation%20of,farm%20land%20among%20rural%20households.&text=The%20top%2020%20per%20cent,only%200.3%20hectare%20on%20average.\nSDG Pakistan. (2021). The Targets. Retrieved from https://www.sdgpakistan.pk/web/goals/goal10\nSocial Europe. (2021). What is inequality? Retrieved from https://www.socialeurope.eu/focus/what-is-inequality\nUN (2020). Reduce inequality within and among countries. Retrieved from https://sdgs.un.org/goals/goal10\nUNDP Pakistan. (2021). Goal 10: Reduced inequalities. Retrieved from https://www.pk.undp.org/content/pakistan/en/home/sustainable-development-goals/goal-10-reduced-inequalities.html"
SDG10=SDG10.replace(not_required,"")



#print(SDG10)
