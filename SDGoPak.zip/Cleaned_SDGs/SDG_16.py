import requests
from bs4 import BeautifulSoup

def Get_Cleaned_String(raw_text):
    data=""
    for i in raw_text:
        data+=i.text
    return data

html=requests.get("https://www.app.com.pk/national/pakistan-needs-to-embrace-sustainable-inclusive-growth-for-enduring-development-kemal/",allow_redirects=True)
raw_data=BeautifulSoup(html.content,"html.parser")

raw_data=raw_data.find("div",class_="entry-content")

SDG16=Get_Cleaned_String(raw_data)
not_required="(adsbygoogle=window.adsbygoogle||[]).push({});"
SDG16=SDG16.replace(not_required,"")
#print(SDG16)