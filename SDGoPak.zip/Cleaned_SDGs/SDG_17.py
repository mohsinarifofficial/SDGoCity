import requests
from bs4 import BeautifulSoup

def Get_Cleaned_String(raw_text):
    data=""
    for i in raw_text:
        data+=i.text
    return data

html=requests.get("https://www.linkedin.com/pulse/sdg-17-partnerships-goals-pakistan-professor-dr-qais-aslam#:~:text=SDG%2017%20is%20%E2%80%9CStrengthen%20the,has%20had%20in%20rehabilitating%20and",allow_redirects=True)
raw_data=BeautifulSoup(html.content,"html.parser")

raw_data=raw_data.find("div",class_="article-main__content")

SDG17=Get_Cleaned_String(raw_data)

print(SDG17)