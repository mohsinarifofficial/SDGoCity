import requests
from bs4 import BeautifulSoup

def Get_Cleaned_String(raw_text):
    data=""
    for i in raw_text:
        data+=i.text
    return data

html=requests.get("https://iips.com.pk/pakistans-performance-on-sdg-11-sustainable-cities-and-communities/",allow_redirects=True)
raw_data=BeautifulSoup(html.content,"html.parser")
raw_data=raw_data.find("div",class_="wpb_wrapper")
#print(raw_data)
SDG11=Get_Cleaned_String(raw_data)
not_required="Conclusion\nGlobally, there is an urban revolution taking place in which the state’s function is being redefined — the job of ensuring that all are supplied for, rather than providing for all. This paves the path for innovative collaborations and partnerships between the government, the commercial sector, communities, and other urban stakeholders. We need to establish a similar enabling environment in which the trademarks of urban settlements — creativity, variety, and enterprise – find new life and energy to alter our urban landscape. A sustainable city demands a public agenda, which can only be achieved if urban governance is made more open and socially responsible.\nBibliography\nAlam, A. R. (2019). Not quite livable, let alone “sustainable”. The News . Retrieved from https://www.thenews.com.pk/tns/detail/590079-not-quite-livablelet-alone-sustainable\n"
SDG11=SDG11.replace(not_required,"")
not_required="(2021). SDG 11: Make cities and human settlements inclusive, safe, resilient and sustainable. SDG Compass. Retrieved from https://sdgcompass.org/sdgs/sdg-11/"

SDG11=SDG11.replace(not_required,"")
not_required="(2021). Sustainable Development Report . Cambridge University Press. Retrieved from https://dashboards.sdgindex.org/static/profiles/pdfs/SDR-2021-pakistan.pdf"
SDG11=SDG11.replace(not_required,"")

not_required="(2011). Task Force Report on Urban Development. Planning and Development Division . Retrieved from http://arifhasan.org/wp-content/uploads/2013/03/TaskForceReport06-05-2011.pdf"
SDG11=SDG11.replace(not_required,"")
not_required="(2020). World Cities Report 2020: The Value of Sustainable Urbanization. UN-Habitat. Retrieved from https://unhabitat.org/World%20Cities%20Report%202020"
SDG11=SDG11.replace(not_required,"")

#print(SDG11)

