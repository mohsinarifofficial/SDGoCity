import requests
from bs4 import BeautifulSoup

def Get_Cleaned_String(raw_text):
    data=""
    for i in raw_text:
        data+=i.text
    return data

html=requests.get("https://iips.com.pk/pakistans-progress-on-sustainable-development-goal-8-decent-work-and-economic-growth/",allow_redirects=True)
raw_data=BeautifulSoup(html.content,"html.parser")
raw_data=raw_data.find("div",class_="wpb_wrapper")
#print(raw_data)
SDG8=Get_Cleaned_String(raw_data)
not_required="Bibliography\nGovernment of Pakistan. (2019). Pakistan’s Implementation of the 2030 Agenda for Sustainable Development.\nUN. (2021). Promote sustained, inclusive and sustainable economic growth, full and productive employment and decent work for all. Retrieved from https://sdgs.un.org/goals/goal8"
SDG8=SDG8.replace(not_required,"")
#print(SDG8)
