import requests
from bs4 import BeautifulSoup

def Get_Cleaned_String(raw_data):
    data=""
    for i in raw_data:
        data+=i.text
    return data    
    

link="https://iips.com.pk/pakistans-progress-on-sdg-2-zero-hunger/#:~:text=Has%20Pakistan%20achieved%20its%20SDG,on%20poverty%20alleviation%E2%80%94SDG%20one."
html=requests.get(link,allow_redirects=True)

sop=BeautifulSoup(html.text,"lxml")

raw_sdg=sop.find("div",class_="wpb_wrapper")
SDG2=Get_Cleaned_String(raw_sdg)

#print(SDG2)

not_required="Sustainable Development Goals | United Nations Development Programme. (2021). Retrieved 26 August 2021, from https://www.undp.org/sustainable-development-goals"
SDG2=SDG2.replace(not_required,"")
not_required="Goal 2: Zero Hunger. (2021). Retrieved 26 August 2021, from https://www.un.org/sustainabledevelopment/hunger/"
SDG2=SDG2.replace(not_required,"")
not_required="FAOSTAT. (2020). Retrieved 27 August 2021, from http://www.fao.org/faostat/en/#country/165"
SDG2=SDG2.replace(not_required,"")
not_required="Retrieved from https://sustainabledevelopment.un.org/content/documents/233812019_06_15_VNR_2019_Pakistan_latest_version.pdf"
SDG2=SDG2.replace(not_required,"")
not_required="Goal 1: End poverty in all its forms everywhere. (2021). Retrieved 26 August 2021, from https://www.un.org/sustainabledevelopment/poverty/"
SDG2=SDG2.replace(not_required,"")
not_required="Pakistan’s Implementation of the 2030 Agenda for Sustainable Development Voluntary National Review. Government of Pakistan."
SDG2=SDG2.replace(not_required,"")
not_required="Government of Pakistan. (2019)."
SDG2=SDG2.replace(not_required,"")
not_required="Bibliography"
SDG2=SDG2.replace(not_required,"")
not_required="Conclusion"
SDG2=SDG2.replace(not_required,"")
not_required="Data availability and quality"
SDG2=SDG2.replace(not_required,"")
not_required="Knowledge and Technology Gaps"
SDG2=SDG2.replace(not_required,"")
not_required="Economy and Finance"
SDG2=SDG2.replace(not_required,"")
not_required="The Pandemic"
SDG2=SDG2.replace(not_required,"")
not_required="How many policies did Pakistan make on SDG 2?"
SDG2=SDG2.replace(not_required,"")
not_required="Pakistan’s Legislative progress on SDG 2"
SDG2=SDG2.replace(not_required,"")
not_required="Has Pakistan achieved its SDG 2 targets?"
SDG2=SDG2.replace(not_required,"")
not_required="Setting Criteria for Measuring Progress"
SDG2=SDG2.replace(not_required,"")
not_required="Pakistan’s Progress on SDGs?"
SDG2=SDG2.replace(not_required,"")
not_required="Introduction"
SDG2=SDG2.replace(not_required,"")
not_required="Preamble"
SDG2=SDG2.replace(not_required,"")

SDG2=SDG2.replace("\n","")





print(SDG2)
