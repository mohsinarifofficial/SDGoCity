import requests
from bs4 import BeautifulSoup

def Get_Cleaned_String(raw_text):
    data=""
    for i in raw_text:
        data+=i.text
    return data 
html=requests.get("https://www.linkedin.com/pulse/is-professor-dr-qais-aslam")
raw_data=BeautifulSoup(html.text,"lxml")
raw_data=raw_data.find_all("div",class_="article-main__content")
SDG3=Get_Cleaned_String(raw_data)
#print(SDG3)
    