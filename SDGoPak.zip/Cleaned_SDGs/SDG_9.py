import requests
from bs4 import BeautifulSoup

def Get_Cleaned_String(raw_text):
    data=""
    for i in raw_text:
        data+=i.text
    return data

html=requests.get("https://iips.com.pk/pakistans-progress-on-sdg-goal-9-industry-innovation-and-infrastructure/",allow_redirects=True)
raw_data=BeautifulSoup(html.content,"html.parser")
raw_data=raw_data.find("div",class_="wpb_wrapper")
#print(raw_data)
SDG9=Get_Cleaned_String(raw_data)
#print(SDG9)
