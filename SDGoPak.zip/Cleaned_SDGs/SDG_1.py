import requests
from bs4 import BeautifulSoup

def Get_Cleaned_String(raw_data):
    data=""
    for i in raw_data:
        data+=i.text
    return data    
    

html=requests.get("https://www.linkedin.com/pulse/poverty-pakistan-sdg-goal-1-professor-dr-qais-aslam#:~:text=SDG1%20has%20seven%20targets%20as,312)%20a%20day%E2%80%9D.")
raw_sdg=BeautifulSoup(html.text,"lxml")
raw_sdg=raw_sdg.find_all("div",class_="article-main__content")
SDG1=Get_Cleaned_String(raw_sdg)
SDG1=SDG1.replace("Professor Dr. Qais Aslam (dr.qais@ucp.edu.pk)","")
#print(SDG1)