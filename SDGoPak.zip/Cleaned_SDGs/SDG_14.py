import requests
from bs4 import BeautifulSoup

def Get_Cleaned_String(raw_text):
    data=""
    for i in raw_text:
        data+=i.text
    return data

html=requests.get("https://iips.com.pk/pathways-to-sustainable-blue-economy-of-pakistan-policy-brief/#:~:text=The%20Sustainable%20Development%20Goals%20(SDG,%2C%20oceans%2C%20and%20marine%20resources.",allow_redirects=True)
raw_data=BeautifulSoup(html.content,"html.parser")
raw_data=raw_data.find("div",class_="wpb_wrapper")
#print(raw_data)
SDG14=Get_Cleaned_String(raw_data)
#print(SDG14)