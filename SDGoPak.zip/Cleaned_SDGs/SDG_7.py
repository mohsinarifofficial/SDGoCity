import requests
from bs4 import BeautifulSoup

def Get_Cleaned_String(raw_text):
    data=""
    for i in raw_text:
        data+=i.text
    return data

html=requests.get("https://www.linkedin.com/pulse/issues-affordable-clean-energy-pakistan-sdg-7-aslam",allow_redirects=True)
raw_data=BeautifulSoup(html.content,"html.parser")
raw_data=raw_data.find("div",class_="article-main__content")
#print(raw_data)
SDG7=Get_Cleaned_String(raw_data)
print(SDG7)
