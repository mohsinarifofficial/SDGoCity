import spacy
from spacy.lang.en.stop_words import STOP_WORDS
from string import punctuation
from heapq import nlargest
from Cleaned_SDGs.SDG_16 import SDG16 as SDG


punctuation=punctuation+"\n"

stop_words=list(STOP_WORDS)
#print(STOP_WORDS)
nlp=spacy.load("en_core_web_sm")
#text="Hy there! the thing is something bad is happening to me, looks like i put my focus on somethoing but cannot keep it up. May thats becuase of those dark powers i got from someone or may be its an output of my own sins. I have done a ot bad things with bad people. I did those things not because i wanted to it was because they made me. "
text=SDG
#text=str(text)
doc=nlp(text)

tokens=[i.text for i in doc]
#step 1
#print(tokens)
word_freq={}
for i in doc:
    if i.text.lower()  not in stop_words:
        if i.text.lower() not in punctuation:
            if i.text.lower() not in word_freq:
                word_freq[i.text.lower()]=1
            else:
                word_freq[i.text.lower()]+=1
                #print(i.text)
#print(word_freq)                    
max_val=max(word_freq.values())
#print(max_val)
#normalization step 2
for i in word_freq.keys():
    word_freq[i]=word_freq[i]/max_val
#print(word_freq)    
#step 3
sent_token=[i for i in doc.sents]
sent_scoer={}
for i in sent_token:
    #print(i)
    for j in i:
        if j.text.lower() in word_freq.keys():
            if i not in sent_scoer:
                sent_scoer[i]=word_freq[j.text.lower()]
            else:
                sent_scoer[i]+=word_freq[j.text.lower()]
#print(sent_scoer)                  
#step 4 
l=int(len(sent_token)*0.15)
#print(l)

summary=nlargest(l,sent_scoer,key=sent_scoer.get)
print(summary)






